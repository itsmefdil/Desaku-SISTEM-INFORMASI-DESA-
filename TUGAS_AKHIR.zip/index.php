<?php 

include 'komponen/header.php';

include 'komponen/navbar.php';

include 'komponen/home.php';

include 'komponen/footer.php';

?>