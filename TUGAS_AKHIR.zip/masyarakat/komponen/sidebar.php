
      <!-- Sidebar Navigation-->
      <nav id="sidebar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
          <div class="avatar"><img src="<?php echo $base_url;?>asset/img/profil.png" alt="..." class="img-fluid rounded-circle"></div>
          <div class="title">
            <h1 class="h5">FADILAH RICZKY</h1>
            <p>BUKAN Web Designer</p>
          </div>
        </div>
        <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
        <ul class="list-unstyled">
          <li><a href="index.php"> <i class="icon-home"></i>Home </a></li>
          <li><a href="artikel.php"> <i class="icon-windows"></i>Artikel </a></li>
          <li><a href="permohonan_surat.php"> <i class="icon-windows"></i>Permohonan Surat </a></li>
          <li><a href="laporan.php"> <i class="icon-windows"></i>Laporan </a></li>
          <li><a href="data_user.php"> <i class="icon-windows"></i><DATA>Drive Cloud</DATA> </a></li>
    
      
      </nav>