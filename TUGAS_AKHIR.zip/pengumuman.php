<?php 

include 'komponen/header.php';

include 'komponen/navbar.php';

include 'komponen/pengumuman.php';

include 'komponen/footer.php';

?>