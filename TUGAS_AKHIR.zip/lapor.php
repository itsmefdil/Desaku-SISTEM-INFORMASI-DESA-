<?php 

include 'komponen/header.php';

include 'komponen/navbar.php';

include 'komponen/lapor.php';

include 'komponen/footer.php';

?>