			<div class="footer-bottom">
				<div class="row">
					<div class="col-md-6 col-sm-6">
						<p>&copy; 2019 Desaku.com. All rights reserved.</p>
					</div>
					<div class="col-md-6 col-sm-6 text-right">
						<ul class="list-inline">
							<li><a href="#">Contact Us</a></li>
							<li><a href="#">Work With Us</a></li>
							<li><a href="#">Advertise</a></li>
							<li><a href="#">Privacy</a></li>
							<li><a href="#">Terms of Service</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<!-- jQuery -->
<script src="<?php echo $base_url;?>asset/js/jquery.min.js"></script>
<script src="<?php echo $base_url;?>asset/js/bootstrap/bootstrap.min.js"></script>
<script src="<?php echo $base_url;?>asset/js/slick/slick.min.js"></script>
<script src="<?php echo $base_url;?>asset/js/theme.js"></script>

</body>
</html>
