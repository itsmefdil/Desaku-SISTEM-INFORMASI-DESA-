<?php include 'koneksi.php';?>
<!DOCTYPE html>
<html lang="zxx">
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>DESAKU</title>

	<!-- Favicon -->
	<link rel="shortcut icon" href="<?php echo $base_url;?>asset/img/favicon.ico">

	<!-- ICON CSS -->
	<link rel="stylesheet" href="<?php echo $base_url;?>asset/js/font-awesome/css/font-awesome.min.css">

	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo $base_url;?>asset/js/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo $base_url;?>asset/js/slick/slick.css">
	<link rel="stylesheet" href="<?php echo $base_url;?>asset/css/animate.css">
	<link rel="stylesheet" href="<?php echo $base_url;?>asset/css/style.css">

	<!-- MODERNIZR -->
     <script src="<?php echo $base_url;?>asset/js/modernizr-2.8.3-respond-1.4.2.min.js"></script>

</head>
<body class="home5">