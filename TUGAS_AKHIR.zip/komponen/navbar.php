<div class="wrapper">
	<header class="header header3 header5 header6">
		<nav class="navbar navbar-default" role="navigation">
			<div class="container">
				<div class="search-bar">
					<input type="search" placeholder="Type search text here...">
					<div class="search-close"><i class="fa fa-times"></i></div>
				</div>
				
				<div class="navbar-header hidden visible-xs">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo $base_url ;?>"> <img src="<?php echo $base_url;?>asset/img/logoy.png" size="10px" class="img-responsive" alt=""/></a>
				</div>				

				<div class="navbar-social">
					<a href="#"><img src="<?php echo $base_url;?>asset/img/icon/3.png" class="img-responsive" alt=""/></a>
					<a href="#"><img src="<?php echo $base_url;?>asset/img/icon/4.png" class="img-responsive" alt=""/></a>
					<a href="#"><img src="<?php echo $base_url;?>asset/img/icon/5.png" class="img-responsive" alt=""/></a>
				</div>

				<div class="navbar-brand hidden-xs">
					<a href="<?php echo $base_url;?>"><img src="<?php echo $base_url;?>asset/img/logoy.png" class="img-responsive" alt=""/></a>
				</div>
				
				<div class="search-trigger pull-right"></div>

				<div class="login pull-right"><a class ="login pull-right" href="<?php echo $base_url;?>login"></a></div>
				
			</div>
		</nav>
		
		
		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="nav-white">
		<div class="container">
		<div class="collapse navbar-collapse navbar-ex1-collapse">
			<ul class="nav navbar-nav">
						<li>
							<a href="<?php echo $base_url;?>">Home </span></a>
		
						</li>					
						<li>
							<a href="<?php echo $base_url;?>berita.php" >Berita </a>
						</li>
						<li>
							<a href="<?php echo $base_url;?>pengumuman.php" >Pengumuman </a>
							
						</li>
						<li>
							<a href="<?php echo $base_url;?>lapor.php">E-Lapor </a>
							
						</li>
				
			</ul>
		</div>
	
		</div>
		</div>
		
		<!-- /.navbar-collapse -->			
	</header>		