<div class="inner-content">	
		<div class="container">
			<div class="section-head">
				<h2>Pengumuman</h2>
			</div>

			<div class="row">
				<div class="col-md-4 col-sm-4">
					<article>
						<a href="../17_post_01.html">
							<div class="article-thumb">
								<img src="img/category/08/1.jpg" class="img-responsive" alt=""/>
							</div>
						</a>
						<div class="post-excerpt">
							<div class="small-title cat">Travel</div>
							<h4><a href="./17_post_01.html">Twitter Stock Surges On Disney Takeover Rumor</a></h4>
							<div class="meta">
								<span>by <a href="#" class="link">Kevin K.</a></span>
								<span>on Sep 23, 2016</span>
								<span class="comment"><i class="fa fa-comment-o"></i> 1</span>
							</div>

							<p>The list of potential Twitter acquirers continues to grow. In addition to recent reports that Salesforce and Google are interested in possibly buying the real-time news</p>
							<a href="#" class="small-title rmore">Read More</a>
						</div>
					</article>
				</div>

				<div class="col-md-4 col-sm-4">
					<article>
						<a href="../17_post_01.html">
							<div class="article-thumb">
								<img src="img/category/08/2.jpg" class="img-responsive" alt=""/>
							</div>
						</a>
						<div class="post-excerpt">
							<div class="small-title cat">Sports</div>
							<h4><a href="./17_post_01.html">These Massive Tech Companies Might Buy Twitter</a></h4>
							<div class="meta">
								<span>by <a href="#" class="link">Matthew L</a></span>
								<span>on Sep 23, 2016</span>
								<span class="comment"><i class="fa fa-comment-o"></i> 4</span>
							</div>

							<p>The list of potential Twitter acquirers continues to grow. In addition to recent reports that Salesforce and Google are interested in possibly buying the real-time news</p>
							<a href="#" class="small-title rmore">Read More</a>
						</div>
					</article>
				</div>

				<div class="col-md-4 col-sm-4">
					<article>
						<a href="../17_post_01.html">
							<div class="article-thumb">
								<img src="img/category/08/3.jpg" class="img-responsive" alt=""/>
							</div>
						</a>
						<div class="post-excerpt">
							<div class="small-title cat">Politics</div>
							<h4><a href="./17_post_01.html">Bayer Reaches Deal to Acquire Monsanto for $66 Billion</a></h4>
							<div class="meta">
								<span>by <a href="#" class="link">Daniel W.</a></span>
								<span>on Sep 23, 2016</span>
								<span class="comment"><i class="fa fa-comment-o"></i> 6</span>
							</div>

							<p>The list of potential Twitter acquirers continues to grow. In addition to recent reports that Salesforce and Google are interested in possibly buying the real-time news</p>
							<a href="#" class="small-title rmore">Read More</a>

						</div>
					</article>
				</div>

			</div>

		