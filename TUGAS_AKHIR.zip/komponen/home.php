<!-- SLIDER -->
	<div class="container-fluid no-padding">
		<div class="home-slider-wrap">
			<div class="home-slider">
				<div>
					<article class="style3 single text-center no-margin">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="container">
								<div class="post-excerpt">
									<div class="small-title cat">Travel</div>
									<h3 class="h1 text-white">Twitter Stock Surges On Disney<br>Takeover Rumor</h3>
									<div class="meta">
										<span class="author"><img src="<?php echo $base_url;?>asset/img/avatar/1.jpg" class="img-circle" alt=""> by Babs C.</span>
										<span>on Sep 22,2016</span>
									</div>
									<div class="meta">
										<span class="comment"><i class="fa fa-comment-o"></i> 5</span>
										<span class="views"><i class="fa fa-eye"></i> 682 views</span>
									</div>
								</div>
							</div>
							<img src="<?php echo $base_url;?>asset/img/home/01/slider/1.jpg" class="bg-img img-full" alt="">
						</div>
					</article>
				</div>
				<div>
					<article class="style3 single text-center no-margin">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="container">
								<div class="post-excerpt">
									<div class="small-title cat">Travel</div>
									<h3 class="h1 text-white">Twitter Stock Surges On Disney<br>Takeover Rumor</h3>
									<div class="meta">
										<span class="author"><img src="<?php echo $base_url;?>asset/img/avatar/1.jpg" class="img-circle" alt=""> by Babs C.</span>
										<span>on Sep 22,2016</span>
									</div>
									<div class="meta">
										<span class="comment"><i class="fa fa-comment-o"></i> 5</span>
										<span class="views"><i class="fa fa-eye"></i> 682 views</span>
									</div>
								</div>
							</div>
							<img src="<?php echo $base_url;?>asset/img/home/01/slider/2.jpg" class="bg-img img-full" alt="">
						</div>
					</article>
				</div>
				<div>
					<article class="style3 single text-center no-margin">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="container">
								<div class="post-excerpt">
									<div class="small-title cat">Travel</div>
									<h3 class="h1 text-white">Twitter Stock Surges On Disney<br>Takeover Rumor</h3>
									<div class="meta">
										<span class="author"><img src="<?php echo $base_url;?>asset/img/avatar/1.jpg" class="img-circle" alt=""> by Babs C.</span>
										<span>on Sep 22,2016</span>
									</div>
									<div class="meta">
										<span class="comment"><i class="fa fa-comment-o"></i> 5</span>
										<span class="views"><i class="fa fa-eye"></i> 682 views</span>
									</div>
								</div>
							</div>
							<img src="<?php echo $base_url;?>asset/img/home/01/slider/3.jpg" class="bg-img img-full" alt="">
						</div>
					</article>
				</div>
			</div>
			<div class="hs-prev"><i class="fa fa-angle-left"></i></div>
			<div class="hs-next"><i class="fa fa-angle-right"></i></div>
		</div>
	</div>
