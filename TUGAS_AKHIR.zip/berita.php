<?php 

include 'komponen/header.php';

include 'komponen/navbar.php';

include 'komponen/berita.php';

include 'komponen/footer.php';

?>