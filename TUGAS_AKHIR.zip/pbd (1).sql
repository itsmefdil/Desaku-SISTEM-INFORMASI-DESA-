-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 11, 2019 at 10:49 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id` int(11) NOT NULL,
  `id_msy` varchar(12) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `kategori` varchar(100) NOT NULL,
  `foto` text NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `id_msy`, `judul`, `kategori`, `foto`, `isi`) VALUES
(1, '1', 'test', 'test', '', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `drivecloud`
--

CREATE TABLE `drivecloud` (
  `id` int(11) NOT NULL,
  `id_msy` varchar(12) NOT NULL,
  `namafile` text NOT NULL,
  `tgl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `elapor_info`
--

CREATE TABLE `elapor_info` (
  `id` int(11) NOT NULL,
  `judul` text NOT NULL,
  `foto` text NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elapor_info`
--

INSERT INTO `elapor_info` (`id`, `judul`, `foto`, `isi`) VALUES
(1, 'elapor', 'Screenshot_20191125_105915.png', '<div align=\"center\"><b> coba ya<br></b></div>   ');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_surat`
--

CREATE TABLE `jenis_surat` (
  `id` int(11) NOT NULL,
  `jenis` text NOT NULL,
  `keterangan` text NOT NULL,
  `nosrt` text NOT NULL,
  `p1` text NOT NULL,
  `p2` text NOT NULL,
  `p3` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_surat`
--

INSERT INTO `jenis_surat` (`id`, `jenis`, `keterangan`, `nosrt`, `p1`, `p2`, `p3`) VALUES
(1, 'SURAT KTP SEMENTARA', '', '', '', '', ''),
(2, 'SURAT IZIN TEMPAT TINGGAL', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `masyarakat`
--

CREATE TABLE `masyarakat` (
  `id_msy` int(11) NOT NULL,
  `nama_msy` varchar(50) NOT NULL,
  `nik_msy` int(20) NOT NULL,
  `alamat_msy` text NOT NULL,
  `rt_rw` varchar(10) NOT NULL,
  `no_hp_msy` int(13) NOT NULL,
  `username_msy` varchar(20) NOT NULL,
  `password_msy` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masyarakat`
--

INSERT INTO `masyarakat` (`id_msy`, `nama_msy`, `nik_msy`, `alamat_msy`, `rt_rw`, `no_hp_msy`, `username_msy`, `password_msy`) VALUES
(3, 'masyarakat', 18330046, 'janabadra', '12', 88888, 'username', 'masyarakat'),
(4, 'akbar', 124, 'akbar', '12', 111, 'username', 'akbar');

-- --------------------------------------------------------

--
-- Table structure for table `pengumuman`
--

CREATE TABLE `pengumuman` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `foto` text NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `waktu` varchar(20) NOT NULL,
  `tempat` varchar(50) NOT NULL,
  `isi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `p_surat`
--

CREATE TABLE `p_surat` (
  `id` int(11) NOT NULL,
  `nik` text NOT NULL,
  `nama` text NOT NULL,
  `tgl` text NOT NULL,
  `jk` text NOT NULL,
  `alamat` text NOT NULL,
  `rtrw` text NOT NULL,
  `kel` text NOT NULL,
  `kec` text NOT NULL,
  `kota` text NOT NULL,
  `prov` text NOT NULL,
  `username` text NOT NULL,
  `foto` text NOT NULL,
  `izin` text NOT NULL,
  `jenis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `p_surat`
--

INSERT INTO `p_surat` (`id`, `nik`, `nama`, `tgl`, `jk`, `alamat`, `rtrw`, `kel`, `kec`, `kota`, `prov`, `username`, `foto`, `izin`, `jenis`) VALUES
(1, '11111', 'Fadilah Riczky', '31-07-1999', 'L', 'Desa Air Asam', '02/01', 'Air Asam', 'Lubai', 'Muara Enim', 'Sumsel', 'admin1', 'nezuko.png', '1', 'SKTPS'),
(2, '123457', 'Jumadi', 'Pekalongan , 1111111', 'P', 'Badran', '4/11', 'Badran', 'Jetis', 'Jogja', 'DIY', 'admin1', 'aaapng', '1', 'SKTPS');

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang`
--

CREATE TABLE `tb_barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `harga_barang` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_barang`
--

INSERT INTO `tb_barang` (`id_barang`, `nama_barang`, `harga_barang`) VALUES
(1, 'topi', '50.000'),
(2, 'sepatu', '400.000');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto` text NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `foto`, `username`, `password`, `level`) VALUES
(4, 'Fadilah Riczky', 'pngfind.com-anime-icon-png-6286332.png', 'admin', 'admin', 'admin'),
(5, 'admin1', '', 'admin1', 'admin1', 'masyarakat'),
(9, 'masyarakat', '', 'masyarakat', 'masyarakat', 'masyarakat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drivecloud`
--
ALTER TABLE `drivecloud`
  ADD PRIMARY KEY (`id`,`id_msy`);

--
-- Indexes for table `elapor_info`
--
ALTER TABLE `elapor_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jenis_surat`
--
ALTER TABLE `jenis_surat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `masyarakat`
--
ALTER TABLE `masyarakat`
  ADD PRIMARY KEY (`id_msy`);

--
-- Indexes for table `pengumuman`
--
ALTER TABLE `pengumuman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `p_surat`
--
ALTER TABLE `p_surat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `drivecloud`
--
ALTER TABLE `drivecloud`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `elapor_info`
--
ALTER TABLE `elapor_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jenis_surat`
--
ALTER TABLE `jenis_surat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `masyarakat`
--
ALTER TABLE `masyarakat`
  MODIFY `id_msy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pengumuman`
--
ALTER TABLE `pengumuman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p_surat`
--
ALTER TABLE `p_surat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_barang`
--
ALTER TABLE `tb_barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
