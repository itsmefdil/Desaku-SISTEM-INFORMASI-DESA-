<?php include '../koneksi.php';?>
<?php include 'komponen/header.php'; ?>

<?php include 'komponen/navbar.php'; ?>

<?php include 'komponen/sidebar.php'; ?>

<?php include 'komponen/body.php'; ?>

<?php include 'komponen/footer.php'; ?>